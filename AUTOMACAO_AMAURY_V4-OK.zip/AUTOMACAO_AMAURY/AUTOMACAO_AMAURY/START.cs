﻿using MaterialSkin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Método mais simples de Acinamento de Portas Arduino.
//https://tecdicas.com/desenvolvendo-um-software-csharp-para-piscar-um-led-arduino-uno/

namespace AUTOMACAO_AMAURY
{
    public partial class START : MaterialSkin.Controls.MaterialForm
    {
        public START()
        {
            InitializeComponent();
            Skin();
        }

        private void Skin()
        {
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.DARK;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
        }

        private void btnAciona1_Click(object sender, EventArgs e)
        {
            ACIONAMENTO1 formAcionamento1 = new ACIONAMENTO1();
            formAcionamento1.Show();
        }

        private void btnAciona2_Click(object sender, EventArgs e)
        {
            ACIONAMENTO2 formAcionamento2 = new ACIONAMENTO2();
            formAcionamento2.Show();
        }

        private void btnAciona3_Click(object sender, EventArgs e)
        {
            ACIONAMENTO3 formAcionamento3 = new ACIONAMENTO3();
            formAcionamento3.Show();
        }
    }
}



////
///CÓDIGO ARDUINO DO PROJETO
///
/**
 * Firmware para controlar uma lâmpada
 * com um módulo de relé via comunicação serial
 * 
 * tecdicas
 * 13/11/2017
 */

//void Lampada()
//{
//    if (digitalRead(10) == HIGH)
//    {
//        digitalWrite(10, LOW);
//    }
//    else
//    {
//        digitalWrite(10, HIGH);
//    }
//}

//void setup()
//{
//    pinMode(10, OUTPUT);
//    Serial.begin(9600);
//}

//void loop()
//{
//    if (Serial.available()) // Se a comunicação Serial estive disponível..
//    {
//        char op = Serial.read(); // Leia a op (Opção) da Serial.

//        if (op == '1')
//        {
//            Lampada();
//        }
//    }
//}
