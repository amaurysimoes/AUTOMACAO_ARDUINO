﻿using MaterialSkin;
using System;
using System.Drawing;
using System.Windows.Forms;
//Referencia do projeto
//https://www.clubedohardware.com.br/forums/topic/1492824-como-integrar-leitura-e-escrita-serial-arduino-c-sem-dar-conflito/

namespace AUTOMACAO_AMAURY
{
    public partial class ACIONAMENTO1 : MaterialSkin.Controls.MaterialForm
    {
        bool estado1 = false;
        bool estado2 = false;

        public ACIONAMENTO1()
        {
            InitializeComponent();

            //Acionamento de porta COM3
            serialPort.BaudRate = 9600;
            serialPort.PortName = "COM3";
        }

        private void ACIONAMENTO1_Load(object sender, EventArgs e)
        {
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.DARK;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
        }

        private void comunicTx(string cTx) // transmite
        {
            if (!serialPort.IsOpen) // Se a porta serial não estiver disponível
            {
                try
                {
                    serialPort.Open();
                    comunicTx(cTx);
                    serialPort.Write(cTx);
                    serialPort.Close();
                }
                catch
                {
                    MessageBox.Show("ARDUINO DESCONECTADO DA COM3", "ATENÇÃO!",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void btnAciona1_Click(object sender, EventArgs e)
        {
            if (estado1 == false)
            {

                comunicTx("0"); // Opção 0 do Arduino
                btnLigaDesliga1.Text = "Ligar";
                lblStatuslLiga1.ForeColor = Color.Red;
                lblStatuslLiga1.Text = "Desligado";
                estado1 = false;

            }
            else
            {

                comunicTx("1"); // Opção 1 do Arduino
                btnLigaDesliga1.Text = "Desligar";
                lblStatuslLiga1.ForeColor = Color.Green;
                lblStatuslLiga1.Text = "Ligado";
                estado1 = true;
            }

            estado1 = !estado1;
        }

        private void btnAciona2_Click(object sender, EventArgs e)
        {
            if (estado2 == false)
            {

                comunicTx("2"); // Opção 2 do Arduino
                btnLigaDesliga2.Text = "Ligar";
                lblStatuslLiga2.ForeColor = Color.Red;
                lblStatuslLiga2.Text = "Desligado";
                estado2 = false;

            }
            else
            {

                comunicTx("3"); // Opção 3 do Arduino
                btnLigaDesliga2.Text = "Desligar";
                lblStatuslLiga2.ForeColor = Color.Green;
                lblStatuslLiga2.Text = "Ligado";
                estado2 = true;
            }

            estado2 = !estado2;
        }

        private void ACIONAMENTO1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (serialPort.IsOpen)
                {
                    serialPort.Close();
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
