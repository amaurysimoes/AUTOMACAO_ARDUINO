﻿namespace AUTOMACAO_AMAURY
{
    partial class ACIONAMENTO1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ACIONAMENTO1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnLigaDesliga1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.btnLigaDesliga2 = new MaterialSkin.Controls.MaterialFlatButton();
            this.lblStatuslLiga1 = new MaterialSkin.Controls.MaterialLabel();
            this.lblStatuslLiga2 = new MaterialSkin.Controls.MaterialLabel();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 74);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(149, 105);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnLigaDesliga1
            // 
            this.btnLigaDesliga1.AutoSize = true;
            this.btnLigaDesliga1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnLigaDesliga1.Depth = 0;
            this.btnLigaDesliga1.Location = new System.Drawing.Point(319, 233);
            this.btnLigaDesliga1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnLigaDesliga1.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnLigaDesliga1.Name = "btnLigaDesliga1";
            this.btnLigaDesliga1.Primary = false;
            this.btnLigaDesliga1.Size = new System.Drawing.Size(111, 36);
            this.btnLigaDesliga1.TabIndex = 1;
            this.btnLigaDesliga1.Text = "Liga Desliga 1";
            this.btnLigaDesliga1.UseVisualStyleBackColor = true;
            this.btnLigaDesliga1.Click += new System.EventHandler(this.btnAciona1_Click);
            // 
            // btnLigaDesliga2
            // 
            this.btnLigaDesliga2.AutoSize = true;
            this.btnLigaDesliga2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnLigaDesliga2.Depth = 0;
            this.btnLigaDesliga2.Location = new System.Drawing.Point(319, 354);
            this.btnLigaDesliga2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnLigaDesliga2.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnLigaDesliga2.Name = "btnLigaDesliga2";
            this.btnLigaDesliga2.Primary = false;
            this.btnLigaDesliga2.Size = new System.Drawing.Size(111, 36);
            this.btnLigaDesliga2.TabIndex = 4;
            this.btnLigaDesliga2.Text = "Liga Desliga 2";
            this.btnLigaDesliga2.UseVisualStyleBackColor = true;
            this.btnLigaDesliga2.Click += new System.EventHandler(this.btnAciona2_Click);
            // 
            // lblStatuslLiga1
            // 
            this.lblStatuslLiga1.AutoSize = true;
            this.lblStatuslLiga1.Depth = 0;
            this.lblStatuslLiga1.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblStatuslLiga1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblStatuslLiga1.Location = new System.Drawing.Point(66, 241);
            this.lblStatuslLiga1.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblStatuslLiga1.Name = "lblStatuslLiga1";
            this.lblStatuslLiga1.Size = new System.Drawing.Size(95, 19);
            this.lblStatuslLiga1.TabIndex = 5;
            this.lblStatuslLiga1.Text = "LigaDesliga1";
            // 
            // lblStatuslLiga2
            // 
            this.lblStatuslLiga2.AutoSize = true;
            this.lblStatuslLiga2.Depth = 0;
            this.lblStatuslLiga2.Font = new System.Drawing.Font("Roboto", 11F);
            this.lblStatuslLiga2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblStatuslLiga2.Location = new System.Drawing.Point(66, 362);
            this.lblStatuslLiga2.MouseState = MaterialSkin.MouseState.HOVER;
            this.lblStatuslLiga2.Name = "lblStatuslLiga2";
            this.lblStatuslLiga2.Size = new System.Drawing.Size(95, 19);
            this.lblStatuslLiga2.TabIndex = 6;
            this.lblStatuslLiga2.Text = "LigaDesliga2";
            // 
            // serialPort
            // 
            this.serialPort.PortName = "COM3";
            // 
            // ACIONAMENTO1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 450);
            this.Controls.Add(this.lblStatuslLiga2);
            this.Controls.Add(this.lblStatuslLiga1);
            this.Controls.Add(this.btnLigaDesliga2);
            this.Controls.Add(this.btnLigaDesliga1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ACIONAMENTO1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ACIONAMENTO1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ACIONAMENTO1_FormClosing);
            this.Load += new System.EventHandler(this.ACIONAMENTO1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private MaterialSkin.Controls.MaterialFlatButton btnLigaDesliga1;
        private MaterialSkin.Controls.MaterialFlatButton btnLigaDesliga2;
        private MaterialSkin.Controls.MaterialLabel lblStatuslLiga1;
        private MaterialSkin.Controls.MaterialLabel lblStatuslLiga2;
        private System.IO.Ports.SerialPort serialPort;
    }
}