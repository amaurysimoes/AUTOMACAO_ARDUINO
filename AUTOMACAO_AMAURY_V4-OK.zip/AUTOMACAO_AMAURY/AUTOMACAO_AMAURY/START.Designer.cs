﻿namespace AUTOMACAO_AMAURY
{
    partial class START
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(START));
            this.gbOpcoes = new System.Windows.Forms.GroupBox();
            this.btnAciona3 = new System.Windows.Forms.Button();
            this.lblAmaury = new System.Windows.Forms.Label();
            this.lblInfo2 = new System.Windows.Forms.Label();
            this.btnAciona2 = new System.Windows.Forms.Button();
            this.btnAciona1 = new System.Windows.Forms.Button();
            this.gbOpcoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbOpcoes
            // 
            this.gbOpcoes.Controls.Add(this.btnAciona3);
            this.gbOpcoes.Controls.Add(this.lblAmaury);
            this.gbOpcoes.Controls.Add(this.lblInfo2);
            this.gbOpcoes.Controls.Add(this.btnAciona2);
            this.gbOpcoes.Controls.Add(this.btnAciona1);
            this.gbOpcoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbOpcoes.ForeColor = System.Drawing.Color.Gray;
            this.gbOpcoes.Location = new System.Drawing.Point(12, 78);
            this.gbOpcoes.Name = "gbOpcoes";
            this.gbOpcoes.Size = new System.Drawing.Size(776, 120);
            this.gbOpcoes.TabIndex = 0;
            this.gbOpcoes.TabStop = false;
            this.gbOpcoes.Text = "ACIONAMENTOS DE SEGURANÇA";
            // 
            // btnAciona3
            // 
            this.btnAciona3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAciona3.ForeColor = System.Drawing.Color.Black;
            this.btnAciona3.Image = global::AUTOMACAO_AMAURY.Properties.Resources.arduino;
            this.btnAciona3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAciona3.Location = new System.Drawing.Point(687, 15);
            this.btnAciona3.Name = "btnAciona3";
            this.btnAciona3.Size = new System.Drawing.Size(83, 66);
            this.btnAciona3.TabIndex = 9;
            this.btnAciona3.Text = "Aciona Segurança";
            this.btnAciona3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAciona3.UseVisualStyleBackColor = true;
            this.btnAciona3.Click += new System.EventHandler(this.btnAciona3_Click);
            // 
            // lblAmaury
            // 
            this.lblAmaury.AutoSize = true;
            this.lblAmaury.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmaury.ForeColor = System.Drawing.Color.Silver;
            this.lblAmaury.Location = new System.Drawing.Point(659, 92);
            this.lblAmaury.Name = "lblAmaury";
            this.lblAmaury.Size = new System.Drawing.Size(111, 20);
            this.lblAmaury.TabIndex = 8;
            this.lblAmaury.Text = "Amaury Huerb";
            // 
            // lblInfo2
            // 
            this.lblInfo2.AutoSize = true;
            this.lblInfo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo2.ForeColor = System.Drawing.Color.Silver;
            this.lblInfo2.Location = new System.Drawing.Point(6, 59);
            this.lblInfo2.Name = "lblInfo2";
            this.lblInfo2.Size = new System.Drawing.Size(277, 20);
            this.lblInfo2.TabIndex = 7;
            this.lblInfo2.Text = "UTILIZAR O MÉTODO DO ACIONA 1";
            // 
            // btnAciona2
            // 
            this.btnAciona2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAciona2.ForeColor = System.Drawing.Color.Black;
            this.btnAciona2.Image = global::AUTOMACAO_AMAURY.Properties.Resources.arduino;
            this.btnAciona2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAciona2.Location = new System.Drawing.Point(598, 15);
            this.btnAciona2.Name = "btnAciona2";
            this.btnAciona2.Size = new System.Drawing.Size(83, 66);
            this.btnAciona2.TabIndex = 1;
            this.btnAciona2.Text = "Aciona Segurança";
            this.btnAciona2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAciona2.UseVisualStyleBackColor = true;
            this.btnAciona2.Click += new System.EventHandler(this.btnAciona2_Click);
            // 
            // btnAciona1
            // 
            this.btnAciona1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAciona1.ForeColor = System.Drawing.Color.Black;
            this.btnAciona1.Image = global::AUTOMACAO_AMAURY.Properties.Resources.arduino;
            this.btnAciona1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAciona1.Location = new System.Drawing.Point(509, 15);
            this.btnAciona1.Name = "btnAciona1";
            this.btnAciona1.Size = new System.Drawing.Size(83, 66);
            this.btnAciona1.TabIndex = 0;
            this.btnAciona1.Text = "Aciona Segurança";
            this.btnAciona1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAciona1.UseVisualStyleBackColor = true;
            this.btnAciona1.Click += new System.EventHandler(this.btnAciona1_Click);
            // 
            // START
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 210);
            this.Controls.Add(this.gbOpcoes);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "START";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AUTOMAÇÃO 1.0";
            this.gbOpcoes.ResumeLayout(false);
            this.gbOpcoes.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbOpcoes;
        private System.Windows.Forms.Button btnAciona1;
        private System.Windows.Forms.Button btnAciona2;
        private System.Windows.Forms.Label lblInfo2;
        private System.Windows.Forms.Label lblAmaury;
        private System.Windows.Forms.Button btnAciona3;
    }
}

