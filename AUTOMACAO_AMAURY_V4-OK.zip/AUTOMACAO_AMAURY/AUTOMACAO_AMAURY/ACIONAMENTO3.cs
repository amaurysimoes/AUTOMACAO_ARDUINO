﻿using MaterialSkin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.IO.Ports;

namespace AUTOMACAO_AMAURY
{
    public partial class ACIONAMENTO3 : MaterialSkin.Controls.MaterialForm
    {
        //Varia de acordo com a porta conectada.
        SerialPort conexao = new SerialPort("COM3", 9600);

        public ACIONAMENTO3()
        {
            InitializeComponent();
            Skin();
        }

        private void Skin()
        {
            var materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.DARK;
            materialSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
        }

        private void btnAtiva_Click(object sender, EventArgs e)
        {
            conexao.Open();
            btnAtiva.BackColor = Color.DarkGray;
            btnDesativa.BackColor = Color.DarkRed;
            //Vai mandar 1 para a porta serial, por isso ativa!
            conexao.Write("A");
            string informacao = conexao.ReadLine();
            txtStatus.Text += informacao + "\n";
            conexao.Close();
        }

        private void btnDesativa_Click(object sender, EventArgs e)
        {
            conexao.Open();
            btnAtiva.BackColor = Color.DarkGreen;
            btnDesativa.BackColor = Color.DarkBlue;
            //Vai mandar 1 para a porta serial, por isso ativa!
            conexao.Write("A");
            string informacao = conexao.ReadLine();
            txtStatus.Text += informacao + "\n";
            conexao.Close();
        }
    }
}
