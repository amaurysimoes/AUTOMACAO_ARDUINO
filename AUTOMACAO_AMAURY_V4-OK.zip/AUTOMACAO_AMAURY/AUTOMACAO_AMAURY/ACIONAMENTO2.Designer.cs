﻿namespace AUTOMACAO_AMAURY
{
    partial class ACIONAMENTO2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ACIONAMENTO2));
            this.lblInforma1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnAtiva = new MaterialSkin.Controls.MaterialFlatButton();
            this.lblInfo = new System.Windows.Forms.Label();
            this.btnDesativa = new MaterialSkin.Controls.MaterialFlatButton();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            this.lblInforma2 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.lblTituloAciona = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInforma1
            // 
            this.lblInforma1.AutoSize = true;
            this.lblInforma1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInforma1.ForeColor = System.Drawing.Color.Silver;
            this.lblInforma1.Location = new System.Drawing.Point(262, 119);
            this.lblInforma1.Name = "lblInforma1";
            this.lblInforma1.Size = new System.Drawing.Size(468, 20);
            this.lblInforma1.TabIndex = 4;
            this.lblInforma1.Text = "Procura o Acionamento na COM3 - Inserir o Método outro projeto";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 74);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(223, 159);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // btnAtiva
            // 
            this.btnAtiva.AutoSize = true;
            this.btnAtiva.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnAtiva.Depth = 0;
            this.btnAtiva.Location = new System.Drawing.Point(266, 401);
            this.btnAtiva.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnAtiva.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnAtiva.Name = "btnAtiva";
            this.btnAtiva.Primary = false;
            this.btnAtiva.Size = new System.Drawing.Size(98, 36);
            this.btnAtiva.TabIndex = 5;
            this.btnAtiva.Text = "ATIVAR COM.";
            this.btnAtiva.UseVisualStyleBackColor = true;
            this.btnAtiva.Click += new System.EventHandler(this.btnAtiva_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.ForeColor = System.Drawing.Color.Silver;
            this.lblInfo.Location = new System.Drawing.Point(617, 74);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(171, 20);
            this.lblInfo.TabIndex = 6;
            this.lblInfo.Text = "TESTE DE MÉTODOS";
            // 
            // btnDesativa
            // 
            this.btnDesativa.AutoSize = true;
            this.btnDesativa.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnDesativa.Depth = 0;
            this.btnDesativa.Location = new System.Drawing.Point(455, 401);
            this.btnDesativa.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btnDesativa.MouseState = MaterialSkin.MouseState.HOVER;
            this.btnDesativa.Name = "btnDesativa";
            this.btnDesativa.Primary = false;
            this.btnDesativa.Size = new System.Drawing.Size(85, 36);
            this.btnDesativa.TabIndex = 7;
            this.btnDesativa.Text = "DESATIVAR";
            this.btnDesativa.UseVisualStyleBackColor = true;
            this.btnDesativa.Click += new System.EventHandler(this.btnDesativa_Click);
            // 
            // lblInforma2
            // 
            this.lblInforma2.AutoSize = true;
            this.lblInforma2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInforma2.ForeColor = System.Drawing.Color.Silver;
            this.lblInforma2.Location = new System.Drawing.Point(262, 154);
            this.lblInforma2.Name = "lblInforma2";
            this.lblInforma2.Size = new System.Drawing.Size(366, 20);
            this.lblInforma2.TabIndex = 8;
            this.lblInforma2.Text = "para fazer a busca automática de porta conectada";
            // 
            // txtStatus
            // 
            this.txtStatus.BackColor = System.Drawing.SystemColors.MenuText;
            this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.ForeColor = System.Drawing.Color.White;
            this.txtStatus.Location = new System.Drawing.Point(266, 270);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(274, 122);
            this.txtStatus.TabIndex = 9;
            // 
            // lblTituloAciona
            // 
            this.lblTituloAciona.AutoSize = true;
            this.lblTituloAciona.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloAciona.ForeColor = System.Drawing.Color.Silver;
            this.lblTituloAciona.Location = new System.Drawing.Point(306, 222);
            this.lblTituloAciona.Name = "lblTituloAciona";
            this.lblTituloAciona.Size = new System.Drawing.Size(197, 20);
            this.lblTituloAciona.TabIndex = 10;
            this.lblTituloAciona.Text = "ACIONAMENTO STATUS:";
            // 
            // ACIONAMENTO2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTituloAciona);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.lblInforma2);
            this.Controls.Add(this.btnDesativa);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnAtiva);
            this.Controls.Add(this.lblInforma1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ACIONAMENTO2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ACIONAMENTO2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInforma1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MaterialSkin.Controls.MaterialFlatButton btnAtiva;
        private System.Windows.Forms.Label lblInfo;
        private MaterialSkin.Controls.MaterialFlatButton btnDesativa;
        private System.IO.Ports.SerialPort serialPort;
        private System.Windows.Forms.Label lblInforma2;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label lblTituloAciona;
    }
}